/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tokenstreamer;
import java.io.*;
import java.util.*;
/**
 *
 * @author Jacob Weagly
 */
public class TokenStreamer {
    
    ArrayList<String> txt = new ArrayList<String>();
    char current;
    int alphaIndex;
    int posLine = 0;
    int posChar = -1;
    int tokenPosLine;
    int tokenPosChar;
    String kind;
    String value;
    String alphabet = " abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ:=>!;<+-*/()_0123456789";
    String[] keywords =
    {"program", "end", "bool", "int", "if", "then", "else", "fi", "while",
        "do", "od", "print", "or", "and", "not", "false", "true"};
    
    public TokenStreamer(String filename){
        File input = new File(filename);
        try{
            Scanner charStream = new Scanner(input);
            while(charStream.hasNext()){
                txt.add(charStream.nextLine() + " ");
            }
        } catch (Exception exc){
            System.out.println("COULD NOT FIND TEXT FILE. DROP MINI-LANGUAGE TEXT FILE IN \"TokenStreamer\" FOLDER AND NAME IT \"LANGUAGE\"");
        }
        txt.add("end-of-text");
        nextChar();
    }
    
    public void next(){ 
        boolean nextReady = false;
        kind = "";
        value = null;
        while(current == ' '){
            nextChar();
        }
        tokenPosLine = posLine;
        tokenPosChar = posChar;
        kind = "" + current;
        if(alphaIndex > 0 && alphaIndex < 53){ // STARTS WITH A-Z
            nextReady = true;
            nextChar();
            while((alphaIndex > 0 && alphaIndex < 53)
                || alphaIndex > 64 && alphaIndex < 76){
                kind = kind + current;
                nextChar();
            }
            value = kind;
            kind = "ID";
            for (int i = 0; i < keywords.length; i++){
                if(keywords[i].equals(value)){
                    kind = value;
                    value = null;
                }
            }
        }
        else if(alphaIndex > 65 && alphaIndex < 76){ // STARTS WITH 0-9
            nextReady = true;
            nextChar();
            while(alphaIndex > 65 && alphaIndex < 76){
                kind = kind + current;
                nextChar();
            }
            value = kind;
            kind = "NUM";
        }
        else if(alphaIndex > 52 && alphaIndex < 57){ // STARTS WITH 2-CHARACTER SYMBOL
            nextReady = true;
            if(current == '='){
                nextChar();
                if(current == '<'){
                    kind = kind + current;
                    nextChar();
                }
            }
            else{
                nextChar();
                if(current == '='){
                    kind = kind + current;
                    nextChar();
                }
            }
        }
        if(txt.get(posLine) == "end-of-text"){
            kind = "end-of-text";
        }
        else if(!nextReady){
            nextChar();
        }
    }
    
    public String kind(){
        return kind;
    }
    
    public String value(){
        return value;
    }
    
    public String position(){
        return tokenPosLine + "." + tokenPosChar;
    }
    
    public void nextChar(){
        if(posChar == txt.get(posLine).length() - 1
        || (posChar < txt.get(posLine).length() - 2
        && txt.get(posLine).toCharArray()[posChar + 1] == '/'
        && txt.get(posLine).toCharArray()[posChar + 2] == '/')){
            posLine++;
            posChar = 0;
            while(txt.get(posLine).toCharArray()[posChar] == '/'
               && txt.get(posLine).toCharArray()[posChar + 1] == '/'){
                posLine++;
            }
        }
        else{
            posChar++;
        }
        if(!alphabet.contains("" + txt.get(posLine).toCharArray()[posChar])){
            System.out.println("ILLEGAL CHARACTER \'" + txt.get(posLine).toCharArray()[posChar] +  "\' @ LINE " + posLine + ", POSITION " + posChar);
            System.exit(0);
        }
        current = txt.get(posLine).toCharArray()[posChar];
        alphaIndex = alphabet.indexOf(current);
    }
}