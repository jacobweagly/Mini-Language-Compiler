/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tokenstreamer;

/**
 *
 * @author Jacob
 */
public class TestDriver {
    
    public static void main(String[] args) {
        TokenStreamer tokenStreamer = new TokenStreamer("LANGUAGE.txt"); // << NAME OF TEXT FILE HERE
        while (tokenStreamer.kind() != "end-of-text")
        {
            tokenStreamer.next();
            System.out.println(tokenStreamer.position() + ", " + tokenStreamer.kind() + ", " + tokenStreamer.value());
        }
    }
}
