/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parser;
import java.util.ArrayList;

/**
 *
 * @author Jacob
 */
public class Parser {
    
    TokenStreamer tokenStreamer;
    boolean correct;
    
    public Parser(String input){
        tokenStreamer = new TokenStreamer(input);
    }
    
    public boolean isSyntacticallyCorrect(){
        correct = true;
        next();
        program();
        return correct;
    }
    
    public void next(){
        tokenStreamer.next();
    }
    
    public String kind(){
        return tokenStreamer.kind();
    }
    
    public String value(){
        return tokenStreamer.value();
    }
    
    public String position(){
        return tokenStreamer.position();
    }
    
    public boolean isIn(String s, String[] arr){
        for(int i = 0; i < arr.length; i++){
            if(s.equals(arr[i])){
                return true;
            }
        }
        return false;
    }
    
    public void accept(String symbol){
        if(kind().equals(symbol)){
            next();
        }
        else if(correct){
            System.out.println("PROGRAM NOT SYNTACTICALLY CORRECT. EXPECTING '" + symbol + "'. FOUND '" + kind() + "' @ POSITION " + position() + ".");
            correct = false;
        }
    }
    
    public void expected(String[] symbols){
        if(correct){
            String message = "PROGRAM NOT SYNTACTICALLY CORRECT. EXPECTING '";
            for(int i = 0; i < symbols.length - 1; i++){
                message += symbols[i] + ", ";
            }
            message += symbols[symbols.length - 1] + "'. FOUND '" + kind() + "' @ POSITION  " + position() + ".";
            System.out.println(message);
            correct = false;
        }
    }
    
    public void program(){
        accept("program");
        accept("ID");
        accept(":");
        body();
        accept("end");
    }
    
    public void body(){
        String arr1[] = {"bool", "int"};
        if(isIn(kind(), arr1)){
            declarations();
        }
        statements();
    }
    
    public void declarations(){
        declaration();
        String arr1[] = {"bool", "int"};
        while(isIn(kind(), arr1)){
            declaration();
        }
    }
    
    public void declaration(){
        next();
        accept("ID");
        accept(";");
    }
    
    public void statements(){
        statement();
        while(kind().equals(";")){
            next();
            statement();
        }
    }
    
    public void statement(){
        if(kind().equals("ID")){
            assignmentStatement();
        }
        else if(kind().equals("if")){
            conditionalStatement();
        }
        else if(kind().equals("while")){
            iterativeStatement();
        }
        else if(kind().equals("print")){
            printStatement();
        }
        else {
            String[] arr1 = {"ID", "if", "while", "print"};
            expected(arr1);
        }
    }
    
    public void assignmentStatement(){
        accept("ID");
        accept(":=");
        expression();
    }
    
    public void conditionalStatement(){
        accept("if");
        expression();
        accept("then");
        body();
        if(kind().equals("else")){
            next();
            body();  
        }
        accept("fi");
    }
    
    public void iterativeStatement(){
        accept("while");
        expression();
        accept("do");
        body();
        accept("od");
    }
    
    public void printStatement(){
        accept("print");
        expression();
    }
    
    public void expression(){
        simpleExpression();
        String[] arr1 = {"<","=<","=","!=",">",">="};
        if(isIn(kind(), arr1)){
            next();
            simpleExpression();
        }
    }
    
    public void simpleExpression(){
        term();
        String[] arr1 = {"+", "-", "or"};
        while(isIn(kind(), arr1)){
            next();
            term();
        }
    }
    
    public void term(){
        factor();
        String[] arr1 = {"*", "/", "and"};
        while(isIn(kind(), arr1)){
            next();
            factor();
        }
    }
    
    public void factor(){
        String[] arr1 = {"-", "not"};
        if(isIn(kind(), arr1)){
            next();
        }
        String[] arr2 = {"true", "false", "NUM"};
        if(isIn(kind(), arr2)){
            literal();
        }
        else if (kind().equals("ID")){
            next();
        }
        else if(kind().equals("(")){
            next();
            expression();
            accept(")");
        }
        else{
            String[] arr3 = {"true", "false", "NUM", "ID", "("};
            expected(arr3);
        }
    }
    
    public void literal(){
        if (kind().equals("NUM")){
            next();
        }
        else {
            booleanLiteral();
        }
    }
    
    public void booleanLiteral(){
        next();
    }
}