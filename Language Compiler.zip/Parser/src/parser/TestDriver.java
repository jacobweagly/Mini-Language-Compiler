/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parser;

/**
 *
 * @author Jacob
 */
public class TestDriver {
    public static void main(String[] args) {
        Parser parser = new Parser("LANGUAGE.txt"); // << NAME OF TEXT FILE HERE
        System.out.println(parser.isSyntacticallyCorrect());
    }
}
