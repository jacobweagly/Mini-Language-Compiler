1. Text is read from the 'LANGUAGE' txt file, which should be a mini-language sample
2. Open 'src > parser > TestDriver' in NetBeans 8.2
3. Run the TestDriver.